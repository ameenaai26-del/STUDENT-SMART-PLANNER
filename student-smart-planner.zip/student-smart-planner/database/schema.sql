-- MySQL 8+ schema for Student Smart Planner.
-- For a fresh local database, the application can also create these tables with JPA.

CREATE DATABASE IF NOT EXISTS student_smart_planner
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE student_smart_planner;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS assignment (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(120) NOT NULL,
    subject VARCHAR(80) NOT NULL,
    description VARCHAR(1500),
    due_date DATE NOT NULL,
    priority VARCHAR(12) NOT NULL,
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    user_id BIGINT NOT NULL,
    CONSTRAINT fk_assignment_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_assignment_user_due (user_id, due_date)
);

CREATE TABLE IF NOT EXISTS subject (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    user_id BIGINT NOT NULL,
    CONSTRAINT fk_subject_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT uq_subject_user_name UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS attendance (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    subject_id BIGINT NOT NULL UNIQUE,
    classes_attended INT NOT NULL DEFAULT 0,
    total_classes INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_attendance_subject FOREIGN KEY (subject_id) REFERENCES subject(id) ON DELETE CASCADE,
    CONSTRAINT chk_attendance_counts CHECK (classes_attended >= 0 AND total_classes >= classes_attended)
);

CREATE TABLE IF NOT EXISTS class_schedule (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(80) NOT NULL,
    class_day VARCHAR(12) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    classroom VARCHAR(60),
    user_id BIGINT NOT NULL,
    CONSTRAINT fk_schedule_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_schedule_user_day_time (user_id, class_day, start_time)
);

CREATE TABLE IF NOT EXISTS study_task (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(140) NOT NULL,
    subject VARCHAR(80),
    due_date DATE NOT NULL,
    priority VARCHAR(12) NOT NULL,
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    user_id BIGINT NOT NULL,
    CONSTRAINT fk_study_task_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_study_task_user_due (user_id, due_date)
);

-- Sample rows are seeded by DemoDataConfig when starting with profiles "demo"
-- (the default H2 setup) or "mysql,demo". It hashes the demo account password
-- with BCrypt and adds example assignments, subjects, attendance, schedule, and task.
