package edu.college.planner.web;

import edu.college.planner.model.*;
import edu.college.planner.repository.*;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Locale;

@Controller
public class PlannerController {
    private final AssignmentRepository assignments;
    private final SubjectRepository subjects;
    private final ClassScheduleRepository schedules;
    private final StudyTaskRepository tasks;

    public PlannerController(AssignmentRepository assignments, SubjectRepository subjects,
                             ClassScheduleRepository schedules, StudyTaskRepository tasks) {
        this.assignments = assignments;
        this.subjects = subjects;
        this.schedules = schedules;
        this.tasks = tasks;
    }

    @GetMapping("/assignments")
    public String assignments(@AuthenticationPrincipal StudentUser user, @RequestParam(defaultValue = "") String q,
                              @RequestParam(defaultValue = "all") String status, Model model) {
        var list = assignments.findAllByOwnerIdOrderByDueDateAsc(user.getId()).stream()
                .filter(a -> q.isBlank() || a.getTitle().toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT))
                        || a.getSubject().toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT)))
                .filter(a -> status.equals("all") || (status.equals("pending") && !a.isCompleted())
                        || (status.equals("completed") && a.isCompleted()))
                .toList();
        model.addAttribute("assignments", list);
        model.addAttribute("q", q);
        model.addAttribute("status", status);
        model.addAttribute("priorities", Priority.values());
        return "assignments";
    }

    @PostMapping("/assignments/save")
    public String saveAssignment(@Valid @ModelAttribute("form") Assignment form, BindingResult result,
                                 @AuthenticationPrincipal StudentUser user, Model model,
                                 RedirectAttributes redirect) {
        if (result.hasErrors()) {
            model.addAttribute("assignments", assignments.findAllByOwnerIdOrderByDueDateAsc(user.getId()));
            model.addAttribute("priorities", Priority.values());
            model.addAttribute("q", "");
            model.addAttribute("status", "all");
            return "assignments";
        }
        Assignment target;
        if (form.getId() == null) {
            target = form;
            target.setOwner(user);
            target.setCompleted(false);
        } else {
            target = assignments.findByIdAndOwnerId(form.getId(), user.getId())
                    .orElseThrow(() -> new IllegalArgumentException("Assignment not found."));
            target.setTitle(form.getTitle());
            target.setSubject(form.getSubject());
            target.setDescription(form.getDescription());
            target.setDueDate(form.getDueDate());
            target.setPriority(form.getPriority());
        }
        assignments.save(target);
        redirect.addFlashAttribute("success", "Assignment saved.");
        return "redirect:/assignments";
    }

    @PostMapping("/assignments/{id}/toggle")
    public String toggleAssignment(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        var assignment = assignments.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Assignment not found."));
        assignment.setCompleted(!assignment.isCompleted());
        assignments.save(assignment);
        redirect.addFlashAttribute("success", assignment.isCompleted() ? "Assignment marked complete." : "Assignment reopened.");
        return "redirect:/assignments";
    }

    @PostMapping("/assignments/{id}/delete")
    public String deleteAssignment(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        assignments.delete(assignments.findByIdAndOwnerId(id, user.getId())
                .orElseThrow(() -> new IllegalArgumentException("Assignment not found.")));
        redirect.addFlashAttribute("success", "Assignment deleted.");
        return "redirect:/assignments";
    }

    @GetMapping("/subjects")
    public String subjects(@AuthenticationPrincipal StudentUser user, Model model) {
        model.addAttribute("subjects", subjects.findAllByOwnerIdOrderByNameAsc(user.getId()));
        return "subjects";
    }

    @PostMapping("/subjects")
    public String addSubject(@RequestParam String name, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        String trimmed = name == null ? "" : name.trim();
        if (trimmed.isBlank() || trimmed.length() > 80) {
            redirect.addFlashAttribute("error", "Enter a subject name up to 80 characters.");
        } else if (subjects.existsByOwnerIdAndNameIgnoreCase(user.getId(), trimmed)) {
            redirect.addFlashAttribute("error", "That subject is already on your list.");
        } else {
            Subject subject = new Subject(trimmed, user);
            subject.setAttendance(new Attendance(subject, 0, 0));
            subjects.save(subject);
            redirect.addFlashAttribute("success", "Subject added.");
        }
        return "redirect:/subjects";
    }

    @PostMapping("/subjects/{id}/attendance")
    public String updateAttendance(@PathVariable Long id, @RequestParam int attended, @RequestParam int total,
                                  @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        var subject = subjects.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Subject not found."));
        if (attended < 0 || total < 0 || attended > total) {
            redirect.addFlashAttribute("error", "Attended classes must be between zero and total classes.");
        } else {
            subject.getAttendance().update(attended, total);
            subjects.save(subject);
            redirect.addFlashAttribute("success", "Attendance updated.");
        }
        return "redirect:/subjects";
    }

    @PostMapping("/subjects/{id}/delete")
    public String deleteSubject(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        subjects.delete(subjects.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Subject not found.")));
        redirect.addFlashAttribute("success", "Subject deleted.");
        return "redirect:/subjects";
    }

    @ModelAttribute("weekDays")
    public WeekDay[] weekDays() { return WeekDay.values(); }

    @ModelAttribute("priorities")
    public Priority[] priorities() { return Priority.values(); }

    @ModelAttribute("form")
    public Assignment assignmentForm() { return new Assignment(); }

    @ModelAttribute("scheduleForm")
    public ClassSchedule scheduleForm() { return new ClassSchedule(); }

    @GetMapping("/timetable")
    public String timetable(@AuthenticationPrincipal StudentUser user, Model model) {
        model.addAttribute("schedules", schedules.findAllByOwnerIdOrderByDayAscStartTimeAsc(user.getId()));
        return "timetable";
    }

    @PostMapping("/timetable/save")
    public String saveSchedule(@Valid @ModelAttribute("scheduleForm") ClassSchedule form, BindingResult result,
                               @AuthenticationPrincipal StudentUser user, Model model, RedirectAttributes redirect) {
        if (form.getStartTime() != null && form.getEndTime() != null && !form.getEndTime().isAfter(form.getStartTime())) {
            result.rejectValue("endTime", "time.invalid", "End time must be later than start time.");
        }
        if (result.hasErrors()) {
            model.addAttribute("schedules", schedules.findAllByOwnerIdOrderByDayAscStartTimeAsc(user.getId()));
            model.addAttribute("weekDays", WeekDay.values());
            return "timetable";
        }
        ClassSchedule target;
        if (form.getId() == null) {
            target = form;
            target.setOwner(user);
        } else {
            target = schedules.findByIdAndOwnerId(form.getId(), user.getId()).orElseThrow(() -> new IllegalArgumentException("Class not found."));
            target.setSubject(form.getSubject());
            target.setDay(form.getDay());
            target.setStartTime(form.getStartTime());
            target.setEndTime(form.getEndTime());
            target.setClassroom(form.getClassroom());
        }
        schedules.save(target);
        redirect.addFlashAttribute("success", "Class schedule saved.");
        return "redirect:/timetable";
    }

    @PostMapping("/timetable/{id}/delete")
    public String deleteSchedule(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        schedules.delete(schedules.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Class not found.")));
        redirect.addFlashAttribute("success", "Class removed.");
        return "redirect:/timetable";
    }

    @GetMapping("/study-tasks")
    public String studyTasks(@AuthenticationPrincipal StudentUser user, Model model) {
        model.addAttribute("tasks", tasks.findAllByOwnerIdOrderByDueDateAsc(user.getId()));
        model.addAttribute("taskForm", new StudyTask());
        return "study-tasks";
    }

    @PostMapping("/study-tasks/save")
    public String saveTask(@Valid @ModelAttribute("taskForm") StudyTask form, BindingResult result,
                           @AuthenticationPrincipal StudentUser user, Model model, RedirectAttributes redirect) {
        if (result.hasErrors()) {
            model.addAttribute("tasks", tasks.findAllByOwnerIdOrderByDueDateAsc(user.getId()));
            return "study-tasks";
        }
        StudyTask target;
        if (form.getId() == null) {
            target = form;
            target.setOwner(user);
            target.setCompleted(false);
        } else {
            target = tasks.findByIdAndOwnerId(form.getId(), user.getId()).orElseThrow(() -> new IllegalArgumentException("Task not found."));
            target.setTitle(form.getTitle());
            target.setSubject(form.getSubject());
            target.setDueDate(form.getDueDate());
            target.setPriority(form.getPriority());
        }
        tasks.save(target);
        redirect.addFlashAttribute("success", "Study task saved.");
        return "redirect:/study-tasks";
    }

    @PostMapping("/study-tasks/{id}/toggle")
    public String toggleTask(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        var task = tasks.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Task not found."));
        task.setCompleted(!task.isCompleted());
        tasks.save(task);
        redirect.addFlashAttribute("success", task.isCompleted() ? "Task completed." : "Task reopened.");
        return "redirect:/study-tasks";
    }

    @PostMapping("/study-tasks/{id}/delete")
    public String deleteTask(@PathVariable Long id, @AuthenticationPrincipal StudentUser user, RedirectAttributes redirect) {
        tasks.delete(tasks.findByIdAndOwnerId(id, user.getId()).orElseThrow(() -> new IllegalArgumentException("Task not found.")));
        redirect.addFlashAttribute("success", "Task deleted.");
        return "redirect:/study-tasks";
    }
}
