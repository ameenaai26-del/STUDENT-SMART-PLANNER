package edu.college.planner.repository;

import edu.college.planner.model.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AssignmentRepository extends JpaRepository<Assignment, Long> {
    List<Assignment> findAllByOwnerIdOrderByDueDateAsc(Long ownerId);
    Optional<Assignment> findByIdAndOwnerId(Long id, Long ownerId);
    long countByOwnerId(Long ownerId);
    long countByOwnerIdAndCompletedFalse(Long ownerId);
    long countByOwnerIdAndCompletedTrue(Long ownerId);
    List<Assignment> findTop5ByOwnerIdAndCompletedFalseAndDueDateGreaterThanEqualOrderByDueDateAsc(Long ownerId, LocalDate from);
}
