package edu.college.planner.service;

import edu.college.planner.model.StudentUser;
import edu.college.planner.repository.StudentUserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RegistrationServiceTest {
    @Test
    void normalizesEmailAndStoresEncodedPassword() {
        StudentUserRepository users = mock(StudentUserRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(users.existsByEmailIgnoreCase("student@example.com")).thenReturn(false);
        when(encoder.encode("SecurePass123")).thenReturn("bcrypt-value");
        when(users.save(any(StudentUser.class))).thenAnswer(invocation -> invocation.getArgument(0));

        StudentUser saved = new RegistrationService(users, encoder)
                .register(" Student Name ", " Student@Example.com ", "SecurePass123");

        assertEquals("student@example.com", saved.getEmail());
        assertEquals("bcrypt-value", saved.getPassword());
        verify(encoder).encode("SecurePass123");
        verify(users).save(any(StudentUser.class));
    }

    @Test
    void rejectsDuplicateEmail() {
        StudentUserRepository users = mock(StudentUserRepository.class);
        PasswordEncoder encoder = mock(PasswordEncoder.class);
        when(users.existsByEmailIgnoreCase("student@example.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class, () ->
                new RegistrationService(users, encoder).register("Student", "STUDENT@example.com", "SecurePass123"));
        verify(users, never()).save(any());
        verifyNoInteractions(encoder);
    }
}
