# Student Smart Planner

A full-stack academic organizer for college students, built with Java 17, Spring Boot, Thymeleaf, Spring Data JPA, and MySQL. The local profile uses file-backed H2 so the project can be run without installing MySQL.

## Project abstract

Student Smart Planner is a web application that helps students manage assignments, attendance, class schedules, and individual study tasks in one place. The dashboard summarizes deadlines, progress, and attendance so students can plan ahead and keep track of their academic responsibilities.

## Objectives

- Keep assignments, due dates, and priorities organized.
- Record class attendance and identify subjects below the 75% target.
- Make a clear weekly view of class times and rooms.
- Break study goals into dated, prioritized tasks.
- Keep each student's information private to their account.

## Modules

1. **Authentication** — student registration, sign in/out, BCrypt password hashing, and server-side validation.
2. **Dashboard** — assignment totals, completion counts, upcoming deadlines, study task progress, and overall attendance.
3. **Assignments** — add, edit, search, filter, mark complete, and delete.
4. **Attendance** — add subjects, update attended/total class counts, and show a warning below 75%.
5. **Timetable** — add, edit, and delete classes displayed by weekday.
6. **Study planner** — add, edit, complete, and delete dated study tasks.

## Technologies

- Java 17
- Spring Boot 3.3
- Spring MVC and Thymeleaf
- Spring Security with BCrypt
- Spring Data JPA / Hibernate
- MySQL 8+ (MySQL profile)
- H2 database (local demo profile)
- Maven
- HTML, CSS, JavaScript, Bootstrap 5

## Run locally with H2

Requirements: Java 17+ and Maven 3.8+.

1. Unzip the project and open a terminal in the `student-smart-planner` folder.
2. Start the application:

   ```bash
   mvn spring-boot:run
   ```

3. Visit `http://localhost:8080`.
4. The demo profile creates a sample account and academic data on first launch:

   - Email: `student@example.com`
   - Password: `Student@123`

   You can also register a new student from the sign-in page. H2 stores data in `./data/student-planner.mv.db`, so the sample data remains between restarts.

The H2 web console is available at `http://localhost:8080/db-console` in the demo profile. Use JDBC URL `jdbc:h2:file:./data/student-planner`, username `sa`, and leave the password blank.

## Run with MySQL

1. Install and start MySQL 8 or newer.
2. Create the schema by running `database/schema.sql` from the MySQL command line or a database client.
3. Configure the connection in your shell. Set your actual values locally; do not commit credentials:

   ```bash
   export MYSQL_URL='jdbc:mysql://localhost:3306/student_smart_planner?useSSL=false&serverTimezone=UTC'
   export MYSQL_USER='your_mysql_user'
   export MYSQL_PASSWORD='your_mysql_password'
   ```

4. Start the MySQL profile:

   ```bash
   mvn spring-boot:run -Dspring-boot.run.profiles=mysql
   ```

   To also create the demo account and sample academic records in MySQL, use:

   ```bash
   mvn spring-boot:run -Dspring-boot.run.profiles=mysql,demo
   ```

The MySQL profile uses environment variables for credentials and Hibernate `update` for convenient college-project setup. For production, use a managed database and a versioned migration tool rather than automatic schema updates.

## Build and test

```bash
mvn clean test
mvn package
java -jar target/student-smart-planner-1.0.0.jar
```

The attendance calculation tests cover the 75% boundary, below-target values, zero classes, and invalid counts.

## First student account

For a clean local database, select **Create your account** on the sign-in screen. Enter a name, a unique email address, and a password of at least 8 characters. The application stores a BCrypt hash, not the original password. The example demo account is for local demonstration only; change or remove it before using a database outside a classroom demo.

## Frontend, backend, and database in simple terms

Thymeleaf fills HTML templates with the current student's information on the Java server. When a student submits a form, Spring MVC sends the request to a controller. The controller checks the signed-in student's account and calls a Spring Data JPA repository. Hibernate translates that repository operation into SQL and saves or loads the data from H2 or MySQL. The response is then rendered as a new HTML page. Spring Security checks the sign-in session on each private page, and BCrypt protects saved passwords.

## MySQL database tables

`users` stores student accounts. `assignment`, `subject`, `class_schedule`, and `study_task` each reference their owner with a foreign key. `attendance` has a one-to-one foreign key to `subject`. The SQL schema is in `database/schema.sql`. Demo records are created by `DemoDataConfig`, which uses BCrypt to hash the demo password before saving it.

## Create a ZIP for submission

From the directory containing the `student-smart-planner` folder:

```bash
zip -r student-smart-planner.zip student-smart-planner \
  -x 'student-smart-planner/target/*' \
     'student-smart-planner/data/*' \
     'student-smart-planner/.idea/*'
```

In Replit, use the file tree's download/export option for the `student-smart-planner` folder, or run the command above in the Shell and download `student-smart-planner.zip`. Include the full folder (especially `pom.xml`, `src/`, `database/`, and `README.md`) in your college submission.

## Suggested report conclusion

Student Smart Planner brings everyday academic planning into one easy-to-use application. Its account-based data access, deadline tracking, attendance calculations, weekly timetable, and study task list give students a practical way to organize their semester. The modular Spring Boot structure also makes the project straightforward to understand, test, and extend.
